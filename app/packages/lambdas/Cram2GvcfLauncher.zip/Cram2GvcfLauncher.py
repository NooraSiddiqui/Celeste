import json
import logging
import re
from pathlib import Path

import boto3
from botocore.exceptions import ClientError


print("Loading function", flush=True)

client = boto3.client("batch")
logger = logging.getLogger()
logger.setLevel(logging.INFO)

#BREANNA re-zip after editing this script
#BREANNA if need to edit script after pipeline already deployed (e.g. new license key),
# manually edit the lambda function script on the console (carefully!) so that you don't need to re-deploy the entire env
# (but make sure you make the same update in git as well)

#BREANNA make sure "-prod" strings get updated to "-prod", etc as you merge into higher branch

def lambda_handler(event, context):
    logger.info("Received event: " + json.dumps(event, indent=2))
    s3_event = parse_event(event)
    bucket = s3_event["Records"][0]["s3"]["bucket"]["name"]
    key = s3_event["Records"][0]["s3"]["object"]["key"]
    logger.info("Processing event for {0} in bucket '{1}'".format(key, bucket))

    if isCram(key):
        inputfile = "s3://{0}/{1}".format(bucket, key)
        outkey_file = Path(key).stem
        safeName = getSafeName(outkey_file)
        jobName = "cram2gvcf_" + safeName
        sampleID = outkey_file.split("_")[-3] #BREANNA just for directory naming convention, but confirm the -3 index is correct, probably want external ID not internal? ask Eric if he cares
        command = [
            "--force",
            "--board-count=1",
            "--ref-dir",
            "s3://hgsccl-op-data/bwa_references/h/grch38/grch38_hashtable/",
            "--cram-input",
            inputfile,
            "--output-directory",
            "s3://{0}/results/{1}/dragen".format(bucket, sampleID), 
            "--output-file-prefix",
            outkey_file,
            "--enable-variant-caller",
            "true",
            "--enable-map-align",
            "false",
            "--vc-enable-vcf-output",
            "true",	
            "--vc-emit-ref-confidence",	
            "GVCF",
            "--vc-hard-filter",
            "'DRAGENHardQUAL:all:QUAL<5.0;LowDepth:all:DP<=1'",
            "--vc-frd-max-effective-depth=40",
            "--qc-cross-cont-vcf",
            "s3://hgsccl-op-data/AoU-resources/hg38-resources/SNP_NCBI_GRCh38.vcf",
            "--qc-coverage-region-1",
            "s3://hgsccl-op-data/AoU-resources/hg38-resources/wgs_coverage_regions.hg38_minus_N.interval_list.bed",
            "--qc-coverage-reports-1",
            "cov_report",
            "--qc-coverage-region-2",
            "s3://hgsccl-op-data/AoU-resources/hg38-resources/acmg59_allofus_19dec2019.GRC38.wGenes.bed",
            "--qc-coverage-reports-2",
            "cov_report",
            "--qc-coverage-region-3",
            "s3://hgsccl-op-data/AoU-resources/hg38-resources/PGx_singleSite_GRCh38_ActualTableToSendToFDA_21jan2020.bed",
            "--qc-coverage-reports-3",
            "cov_report",
            "--lic-server",
            "M8Iak3VyA28=:MPVp9ylCwsEvzXwBdBZFJumdk5r3dd0n@license.edicogenome.com",
        ]
        try:
            response = client.submit_job(
                jobName=jobName,
                jobQueue="reprocessing-queue-prod",
                jobDefinition="dragen-prod",
                parameters= {"project": "AoU-reprocessing", "user": "lambda", "hgsccl:env": "prod"},
                tags={"hgsccl:project": "AoU-reprocessing", "user": "lambda", "hgsccl:purpose": "cram2gvcf", "hgsccl:env": "prod"},
                propagateTags=True,
                containerOverrides={"command": command},
            )
            # Logs Batch submit_job response
            print("Response: " + json.dumps(response, indent=2))
        except ClientError as e:
            logger.error(e.response["Error"]["Message"])
            raise
        logger.info("Job queued for {0}: {1}".format(key, response["jobId"]))
        # push_sample_tracker() #BREANNA
        return "done"
    else:
        logger.info(
            "key: {} in bucket: {} not a cram file. No reports submitted.".format(
                key, bucket
            )
        )
        return "done"


def push_sample_tracker():
    pass


def parse_event(event):
    record = event["Records"][0]
    if "EventSource" in record and record["EventSource"] == "aws:sns":
        message = record["Sns"]["Message"]
        if type(message) is not str:
            # if configured json test events happen to be type dict, returns as is
            return message
        else:
            return json.loads(message)  # SNS event str to object
    else:
        raise ValueError("Function only supports input from events with a source type of: aws.sns")


def getSafeName(input):
    return re.sub(r"[^\w]", "_", input)[:100]


def isCram(key):
    suffix = (".cram")
    if key.endswith(suffix):
        return True
    else:
        return False
